//  For zip fuctionality, you must instruct unity to import the relevant C# assemblies.
//  To do so create a  file named: "csc.rsp" with notepad++ or similar and save it inside the "assets" folder of your project containing the following lines: 
//      -r:System.IO.Compression.dll
//      -r:System.IO.Compression.FileSystem.dll


using System;
using System.IO;
using System.IO.Compression;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

public class AutoSaveUI : EditorWindow
{
    public static string AutoSaveMessage { get; set; }
    public static string AutoRecoverMessage { get; set; }

    private void OnGUI()
    {
        GUILayout.Space(5);

        PersistentData.AutoSaveEnabled =
            EditorGUILayout.BeginToggleGroup("AutoSave", PersistentData.AutoSaveEnabled);
        PersistentData.AutoSaveFrequency = (int) EditorGUILayout.Slider("AutoSave (minutes):",
            PersistentData.AutoSaveFrequency, 1, 30);
        GUILayout.Label($"Last Saved: {PersistentData.GetLastSaveTimeStr()}");
        GUILayout.Label($"{ SceneManager.GetActiveScene().name } is {IsDirtyMessage()}.");
        GUILayout.Label(AutoSaveMessage);
        EditorGUILayout.EndToggleGroup();

        GUILayout.Space(20);

        PersistentData.AutoRecoverEnabled =
            EditorGUILayout.BeginToggleGroup("AutoRecover", PersistentData.AutoRecoverEnabled);
        PersistentData.AutoRecoverFrequency = (int) EditorGUILayout.Slider("AutoRecover (minutes):",
            PersistentData.AutoRecoverFrequency, 1, 60);
        GUILayout.Label($"Last AutoRecover: {PersistentData.GetLastAutoRecoverTimeStr()}");
        GUILayout.Label(AutoRecoverMessage);
        EditorGUILayout.EndToggleGroup();
        
        

        GUILayout.Space(20);
        GUILayout.BeginHorizontal();
        GUILayout.Label($"AutoRecover Archive Name:", GUILayout.Width(160));
        PersistentData.ZipName = GUILayout.TextField(AutoSave.ExtractProjectName(), GUILayout.Width(150));
        
        GUILayout.EndHorizontal();


        if (GUILayout.Button("Set Archive Save Location"))
        {
            AutoSave.GetArchiveSavePath();
        }
        if (GUILayout.Button(("Set Root for AutoRecover Archive")))
        {
            AutoSave.GetAutoZipRootFolder();
        }
        if (GUILayout.Button("Create AutoRecover Archive Now!"))
        {
  
            if (PersistentData.ZipArchivePath == "")
            {
                AutoSave.GetArchiveSavePath();
            }

            
            if (PersistentData.ZipRoot == "")
            {
                AutoSave.GetAutoZipRootFolder();
            }
            
           AutoSave.ZipUnity();
        }

        
        
    }




    private string IsDirtyMessage()
    {
        return SceneManager.GetActiveScene().isDirty ? "dirty" : "clean";
    }

    [MenuItem("Window/AutoSave")]
    private static void Init()
    {
        // Get existing open window or if none, make a new one:
        var inspectorType = Type.GetType("UnityEditor.InspectorWindow,UnityEditor.dll");
        EditorWindow window = GetWindow<AutoSaveUI>("AutoSave", inspectorType);
        window.Show();
    }
    
    
}