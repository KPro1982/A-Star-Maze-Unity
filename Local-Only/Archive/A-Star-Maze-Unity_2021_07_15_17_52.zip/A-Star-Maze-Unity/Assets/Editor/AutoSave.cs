using System;
using System.IO;
using System.IO.Compression;
using UnityEditor;
using UnityEditor.Experimental;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

[InitializeOnLoad]
public class AutoSave : EditorWindow
{
    public delegate bool DelegateIsValidMethod(out DateTime _lastSaved);

    static AutoSave()
    {
        EditorApplication.update += HandleUpdate;
        EditorApplication.playModeStateChanged += HandlePlayModeState;
        EditorSceneManager.sceneSaved += HandleSceneSaved;
        IsAutoSaveEnabled = PersistentData.AutoSaveEnabled;
        IsAutoRecoverEnabled = PersistentData.AutoRecoverEnabled;
        AutoSaveUI.AutoSaveMessage = "Saving...";
    }

    public static bool IsAutoSaveEnabled { get; set; }

    public static bool IsAutoRecoverEnabled { get; set; }


    public static void HandleUpdate()
    {
        var elapsedSaveTime = -1;
        var elapsedRecoverTime = -1;
        
        if (IsAutoSaveEnabled)
        {
            if (CheckLastSaveTime(PersistentData.AutoSaveFrequency * 60, out elapsedSaveTime))
            {
                SaveScene();
            }
            AutoSaveUI.AutoSaveMessage = $"Next save in {PersistentData.AutoSaveFrequency * 60 - elapsedSaveTime} seconds.";
        }



        if (IsAutoRecoverEnabled)
        {
            if (CheckLastAutoRecoverTime(PersistentData.AutoRecoverFrequency * 60, out elapsedRecoverTime))
            {
                ZipUnity();
            }
            AutoSaveUI.AutoRecoverMessage = $"Next auto recover in {PersistentData.AutoRecoverFrequency * 60 - elapsedRecoverTime} seconds.";
        }
        
    }

    private static void HandleSceneSaved(Scene scene)
    {
        if (IsAutoSaveEnabled)
        {
            PersistentData.LastSavedTime = DateTime.Now;
        }
    }
    

    private static void HandlePlayModeState(PlayModeStateChange state)
    {
        if (IsAutoSaveEnabled)
        {
            if (state == PlayModeStateChange.ExitingEditMode)
            {
                SaveScene();
            }
        }
    }

    private static void TimedSave()
    {
        SaveScene();
    }

    public static void SaveAfter(int seconds)
    {
        if (CheckLastSaveTime(seconds))
        {
            SaveScene();
        }
    }

    private static bool CheckLast(int frequency, DelegateIsValidMethod _IsValid)
    {
        return CheckLast(frequency, out var elapsed, PersistentData.TryGetLastAutoRecoverTime);
    }

    private static bool CheckLastSaveTime(int _frequency)
    {
        return CheckLast(_frequency, PersistentData.TryGetLastSavedTime);
    }

    private static bool CheckLastSaveTime(int autoSaveFrequency, out int _elapsedTime)
    {
        return CheckLast(autoSaveFrequency, out _elapsedTime, PersistentData.TryGetLastSavedTime);
    }

    private static bool CheckLastAutoRecoverTime(int seconds)
    {
        return CheckLast(seconds, PersistentData.TryGetLastAutoRecoverTime);
    }

    private static bool CheckLastAutoRecoverTime(int seconds, out int _elapsedTime)
    {
        return CheckLast(seconds, out _elapsedTime, PersistentData.TryGetLastAutoRecoverTime);
    }

    private static bool CheckLast(int _frequency, out int _elapsedTime,
        DelegateIsValidMethod _IsValid)
    {
        DateTime currentTime = DateTime.Now;
        _elapsedTime = -1;
        DateTime lastSaved;
        TimeSpan elapsedSpan;

        if (!_IsValid(out lastSaved))
        {
            return true;
        }

        elapsedSpan = currentTime.Subtract(lastSaved);
        _elapsedTime = ((int) elapsedSpan.TotalSeconds);
         
        
            
        if (_elapsedTime >= _frequency)
        {
            return true;
        }

        return false;
    }

    public static void SaveScene()
    {
        
        if ((float) (EditorApplication.timeSinceStartup % 1000000) > 30)
        {
            if (!EditorApplication.ExecuteMenuItem("File/Save Project") ||
                !EditorApplication.ExecuteMenuItem("File/Save"))
            {
                Debug.Log("Error: Save not successful");
                Debug.Assert(EditorApplication.ExecuteMenuItem("File/Save Project") == true &&
                             EditorApplication.ExecuteMenuItem("File/Save") == true);
            }
            else
            {
                if(!SceneManager.GetActiveScene().isDirty)
                {
                    PersistentData.LastSavedTime = DateTime.Now;
                }
            }
        }
        else
        {
            Debug.Log("Skipping initial save on application open.");
        }
    }

    /*private static void SaveAutoRecover()
    {
        PersistentData.LastAutoRecoverTime = DateTime.Now;
        SetupArchiveFolders();

        var sceneName = SceneManager.GetActiveScene().name;
        var autoRecoverSavePath = PersistentData.AutoRecoverSavePath;

        var savePath = autoRecoverSavePath + "/" + sceneName + "_" +
                       DateTime.Now.ToString("yyyy_MM_dd_HH_mm") + ".unity";

        if (EditorSceneManager.SaveScene(SceneManager.GetActiveScene(), savePath, true))
        {
            Debug.Log($"AutoRecover saved: {savePath}");
        }
        else
        {
            Debug.Log("AutoRecover failed");
        }
        

    }*/

    public static void ZipUnity()
    {
        SetupArchiveFolders();
        PersistentData.LastAutoRecoverTime = DateTime.Now;
        String _zipPath = PersistentData.ZipArchivePath + "\\" + PersistentData.ZipName + "_" +
                         DateTime.Now.ToString("yyyy_MM_dd_HH_mm") + ".zip";
        String _zipRoot = PersistentData.ZipRoot;

        try
        {

            ZipFile.CreateFromDirectory(_zipRoot, _zipPath);
        }
        catch
        {
            // ignored
        }
    }

    private static void SetupArchiveFolders()
    {
        if (PersistentData.ZipArchivePath == "")
        {
            GetArchiveSavePath();
        }

        if (PersistentData.ZipRoot == "")
        {
            GetAutoZipRootFolder();
        }
    }

    public static string ExtractProjectName()
    {
          
        String[] path;
        path = Application.dataPath.Split('\\', '/');
        String result = path[path.Length - 2];
        return result;
    }
    
    public static void GetArchiveSavePath()
    {
        String tempPath =
            EditorUtility.OpenFolderPanel("Set New ZipArchive Folder", Application.dataPath, "");
        PersistentData.ZipArchivePath = tempPath + "\\Archive";
        PersistentData.AutoRecoverSavePath = tempPath + "\\AutoSave";
        Directory.CreateDirectory(PersistentData.ZipArchivePath);
        Directory.CreateDirectory(PersistentData.AutoRecoverSavePath);
    }

    public static void GetAutoZipRootFolder()
    {
        String tempZipRoot = EditorUtility.OpenFolderPanel(
            "Set New Root to archive (subfolders automatically included)", Application.dataPath, "");
        PersistentData.ZipRoot = tempZipRoot;
    }
}