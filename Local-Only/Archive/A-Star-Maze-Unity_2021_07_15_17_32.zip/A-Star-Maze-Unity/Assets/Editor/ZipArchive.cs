using System.IO;
using System.IO.Compression;
using UnityEditor;

/*namespace Editor
{
    public class Archive : EditorWindow
    {
        private FileStream _zipToOpen =
            new FileStream(@"c:\users\exampleuser\release.zip", FileMode.Open);

        private ZipArchive archive = new ZipArchive(_zipToOpen, ZipArchiveMode.Update);
        ZipArchiveEntry readmeEntry = archive.CreateEntry("Readme.txt");
        private StreamWriter _writer = new StreamWriter(readmeEntry.Open());
        _writer.WriteLine("Information about this package.");
        _writer.WriteLine("========================");
    

    }
}*/